from modelx.serialize.jsonvalues import *

_formula = None

_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def MortAsmp1(Year=None): pass


def MortAsmp2(Year=None): pass


def Morb1(Year=None): pass


def Morb2(Year=None): pass


def Morb3(Year=None): pass


def Morb4(Year=None): pass


def Morb5(Year=None): pass


def LapseRate1(Year=None): pass



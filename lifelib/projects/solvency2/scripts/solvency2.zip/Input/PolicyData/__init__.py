from modelx.serialize.jsonvalues import *

def _formula(Policy=None): pass


_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def Product(): pass


def PolicyType(): pass


def Gen(): pass


def Channel(): pass


def Duration(): pass


def Sex(): pass


def IssueAge(): pass


def PaymentMode(): pass


def PremFreq(): pass


def PolicyTerm(): pass


def MaxPolicyTerm(): pass


def PolicyCount(): pass


def SumAssured(): pass



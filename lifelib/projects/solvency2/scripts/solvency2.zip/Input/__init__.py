from modelx.serialize.jsonvalues import *

_formula = None

_bases = []

_allow_none = True

_spaces = [
    "PolicyData",
    "MortalityTables",
    "ProductSpec",
    "Assumption",
    "AssumptionTables",
    "Scenarios"
]

# ---------------------------------------------------------------------------
# Cells

def DiscountRate(SumAssured=None): pass


def PremWaiverCost(PaymentTerm=None): pass


def CorrLife(row=None, col=None): pass


def Factor(risk=None, shock=None, scope=None, extrakey=None): pass



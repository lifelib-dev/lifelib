from modelx.serialize.jsonvalues import *

def _formula(TableID=None): pass


_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def MortalityTable(Sex=None, Age=None): pass



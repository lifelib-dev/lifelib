from modelx.serialize.jsonvalues import *

_formula = None

_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def BaseMort(Product=None, PolType=None, Gen=None): pass


def MortFactor(Product=None, PolType=None, Gen=None): pass


def Surrender(Product=None, PolType=None, Gen=None): pass


def Renewal(Product=None, PolType=None, Gen=None): pass


def InvstRet(Product=None, PolType=None, Gen=None): pass


def CommInitPrem(Product=None, PolType=None, Gen=None): pass


def CommRenPrem(Product=None, PolType=None, Gen=None): pass


def CommRenTerm(Product=None, PolType=None, Gen=None): pass


def ExpsAcqSA(Product=None, PolType=None, Gen=None): pass


def ExpsAcqAnnPrem(Product=None, PolType=None, Gen=None): pass


def ExpsAcqPol(Product=None, PolType=None, Gen=None): pass


def ExpsMaintSA(Product=None, PolType=None, Gen=None): pass


def ExpsMaintPrem(Product=None, PolType=None, Gen=None): pass


def ExpsMaintPol(Product=None, PolType=None, Gen=None): pass


def InflRate(Product=None, PolType=None, Gen=None): pass


def CnsmpTax(Product=None, PolType=None, Gen=None): pass



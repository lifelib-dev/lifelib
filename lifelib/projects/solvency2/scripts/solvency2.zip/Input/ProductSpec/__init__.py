from modelx.serialize.jsonvalues import *

_formula = None

_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def LoadAcqSAParam1(Product=None, PolType=None, Gen=None): pass


def LoadAcqSAParam2(Product=None, PolType=None, Gen=None): pass


def LoadMaintSA(Product=None, PolType=None, Gen=None): pass


def LoadMaintSA2(Product=None, PolType=None, Gen=None): pass


def LoadMaintPremParam1(Product=None, PolType=None, Gen=None): pass


def LoadMaintPremParam2(Product=None, PolType=None, Gen=None): pass


def SurrChargeParam1(Product=None, PolType=None, Gen=None): pass


def SurrChargeParam2(Product=None, PolType=None, Gen=None): pass


def MortTablePrem(Product=None, PolType=None, Gen=None): pass


def MortTableVal(Product=None, PolType=None, Gen=None): pass


def IntRatePrem(Product=None, PolType=None, Gen=None): pass


def IntRateVal(Product=None, PolType=None, Gen=None): pass


def LapseRatePrem(Product=None, PolType=None, Gen=None): pass


def LapseRateVal(Product=None, PolType=None, Gen=None): pass


def Hsx(Product=None, PolType=None, Gen=None): pass


def Tsx(Product=None, PolType=None, Gen=None): pass


def Hax(Product=None, PolType=None, Gen=None): pass


def Tax(Product=None, PolType=None, Gen=None): pass



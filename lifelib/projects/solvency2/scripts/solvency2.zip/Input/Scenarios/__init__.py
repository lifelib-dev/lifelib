from modelx.serialize.jsonvalues import *

def _formula(ScenID=None): pass


_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def IntRate(Year=None): pass



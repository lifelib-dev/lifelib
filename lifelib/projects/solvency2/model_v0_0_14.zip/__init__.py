from modelx.serialize.jsonvalues import *

_name = "solvency2"

_allow_none = False

_spaces = [
    "Input",
    "LifeTable",
    "Policy",
    "Assumption",
    "Economic",
    "SCR_life",
    "BaseProj",
    "PV",
    "Override"
]


from modelx.serialize.jsonvalues import *

_formula = None

_bases = []

_allow_none = None

_spaces = [
    "Mortality",
    "Lapse",
    "LapseMass",
    "Expense"
]


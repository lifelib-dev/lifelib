from modelx.serialize.jsonvalues import *

_name = "simplelife"

_allow_none = False

_spaces = [
    "Input",
    "LifeTable",
    "Policy",
    "Assumption",
    "Economic",
    "BaseProj",
    "PV",
    "Projection"
]


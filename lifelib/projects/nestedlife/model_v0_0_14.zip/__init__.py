from modelx.serialize.jsonvalues import *

_name = "nestedlife"

_allow_none = False

_spaces = [
    "Input",
    "LifeTable",
    "Policy",
    "Assumption",
    "Economic",
    "PresentValue",
    "BaseProj",
    "OuterProj"
]


from modelx.serialize.jsonvalues import *

_formula = lambda point_id: None

_bases = []

_allow_none = None

_spaces = []

# ---------------------------------------------------------------------------
# Cells

def model_point():
    return model_point_data.loc[point_id]


def sum_assured(): return model_point()["sum_assured"]


def age_at_entry(): return model_point()["age_at_entry"]


def term_y(): return model_point()["term_y"]


def init_pols_if(): return 1


def sex(): return model_point()["sex"]


def proj_len(): return 12 * term_y() + 1


def cost_inflation_pa(): return 0.02


def initial_expense(): return 500


def expense_pp(): return 10


def disc_factors():
    return np.array(list((1 + disc_rate_mth()[t])**(-t) for t in range(proj_len())))


def net_cf(t):
    return premiums(t) - claims(t) - expenses(t)


def premium_pp(t):
    """monthly premium"""
    return round((1 + loading_pprem()) * risk_prem_solved, 2)


def claim_pp(t):
    # if t == 0:
    #     return sum_assured()
    # elif t > term_y() * 12:
    #     return 0
    # elif shape == "level":
    #     return sum_assured()
    # elif shape == "decreasing":
    #     r = (1+0.07)**(1/12)-1
    #     S = sum_assured()
    #     T = term_y() * 12
    #     outstanding = S * ((1+r)**T - (1+r)**t)/((1+r)**T - 1)
    #     return outstanding
    # else:
    #     raise ValueError("Parameter 'shape' must be 'level' or 'decreasing'")
    return sum_assured()


def inflation_factor(t):
    """annual"""
    return (1 + cost_inflation_pa)**(t//12)


def premiums(t):
    return premium_pp(t) * num_pols_if(t)


def duration(t):
    """duration in force in years"""
    return t//12


def claims(t):
    return claim_pp(t) * num_deaths(t)


def expenses(t):
    if t == 0:
        return initial_expense()
    else:
        return num_pols_if(t) * expense_pp()/12 * inflation_factor(t)


def num_pols_if(t):
    """number of policies in force"""
    if t==0:
        return init_pols_if()
    elif t > term_y() * 12:
        return 0
    else:
        return num_pols_if(t-1) - num_exits(t-1) - num_deaths(t-1)


def num_exits(t):
    """exits occurring at time t"""
    return num_pols_if(t) * (1-(1 - lapse_rate(t))**(1/12))


def num_deaths(t):
    """deaths occurring at time t"""
    return num_pols_if(t) * q_x_mth(t)


def age(t):
    return age_at_entry + t//12


def q_x(t):
    #if smoker_status == "N":
    #    return qx_non_smoker(t)
    #elif smoker_status == "S":
    #    return qx_smoker(t)
    return mort_qx[str(min(5, duration(t)))][age(t)]


def commission(t): 
    return premiums(t) if duration(t) == 0 else 0


def npv_claims():
    return sum(list(claims(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


def npv_expenses():
    return sum(list(expenses(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


def npv_commission():
    return sum(list(commission(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


def npv_premiums():
    return sum(list(premiums(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


def q_x_mth(t):
    return 1-(1- q_x(t))**(1/12)


def disc_rate_mth():
    return np.array(list((1 + disc_rate_annual[t//12])**(1/12) - 1 for t in range(proj_len())))


def result():

    data = {
        "Premiums": [premiums(t) for t in range(proj_len())],
        "Claims": [claims(t) for t in range(proj_len())],
        "Expenses": [expenses(t) for t in range(proj_len())],
        "Policies IF": [num_pols_if(t) for t in range(proj_len())],
        "Policies Death": [num_deaths(t) for t in range(proj_len())],
        "Policies Exits": [num_exits(t) for t in range(proj_len())]

    }
    return pd.DataFrame.from_dict(data)


def lapse_rate(t):
    return max(0.1 - 0.02 * duration(t), 0.02)


def pv_pols_if():
    return sum(list(num_pols_if(t) for t in range(proj_len())) * disc_factors()[:proj_len()])


def loading_pprem():
    return 0.15


def risk_premium():

    return round((npv_claims() + npv_expenses() + npv_commission()) / pv_pols_if(), 2)


def risk_prem_calc():

    return round((npv_claims() + npv_expenses() + npv_commission()) / pv_pols_if(), 2)


def solv_prem_obj():
    return (npv_premiums() - npv_claims() - npv_expenses() - npv_commission())**2


# ---------------------------------------------------------------------------
# References

disc_rate_annual = ("Pickle", 1687671454664)

model_point_data = ("Pickle", 1687671558088)

mort_qx = ("Pickle", 1687671659528)

point_id = 100

pd = ("Module", "pandas")

risk_prem_solved = ("Pickle", 1687671444848)

Solver = ("DataClient", 1687671331144)
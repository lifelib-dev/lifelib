from scipy.optimize import minimize_scalar  


def solv_premium(projection):
    
    def solv_prem_inner(x):
        projection.risk_prem_solved = x
        return projection.solv_prem_obj()
    
    res = minimize_scalar(solv_prem_inner)
    return res.x

from modelx.serialize.jsonvalues import *

_name = "TermAssurance"

_allow_none = False

_spaces = [
    "Projection"
]

# ---------------------------------------------------------------------------
# References

np = ("Module", "numpy")
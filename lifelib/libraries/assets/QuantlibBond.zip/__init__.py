from modelx.serialize.jsonvalues import *

_name = "BondModel"

_allow_none = False

_spaces = [
    "Bond"
]

# ---------------------------------------------------------------------------
# References

ql = ("Module", "QuantLib")